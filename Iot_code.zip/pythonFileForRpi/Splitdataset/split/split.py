import os
import random
import shutil

# Set the directories
input_dir = 'C:/'
train_dir = 'C:/train'
val_dir = 'C:/valid'

# Set the validation split
val_split = 0.2

# Get the list of files in the input directory
files = os.listdir(input_dir)

# Shuffle the files
random.shuffle(files)

# Get the split index
split_idx = int(len(files) * val_split)

# Split the files into training and validation sets
train_files = files[split_idx:]
val_files = files[:split_idx]

# Move the training files to the training directory
for file in train_files:
    src = os.path.join(input_dir, file)
    dst = os.path.join(train_dir, file)
    shutil.copy(src, dst)

# Move the validation files to the validation directory
for file in val_files:
    src = os.path.join(input_dir, file)
    dst = os.path.join(val_dir, file)
    shutil.copy(src, dst)
