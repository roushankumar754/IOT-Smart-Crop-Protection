import RPi.GPIO as GPIO
import time

# Define the GPIO pins for the ultrasonic sensor and LED
TRIG_PIN = 26
ECHO_PIN = 20
BUZZER_PIN = 21
LED_PIN = 16

# Set up the GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG_PIN, GPIO.OUT)
GPIO.setup(ECHO_PIN, GPIO.IN)
GPIO.setup(BUZZER_PIN, GPIO.OUT)
GPIO.setup(LED_PIN, GPIO.OUT)

# Function to read the distance from the ultrasonic sensor
def read_distance():
    # Send a pulse to the sensor
    GPIO.output(TRIG_PIN, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, GPIO.LOW)

    # Wait for the pulse to return
    while GPIO.input(ECHO_PIN) == 0:
        pulse_start_time = time.time()
    while GPIO.input(ECHO_PIN) == 1:
        pulse_end_time = time.time()

    # Calculate the distance from the pulse duration
    pulse_duration = pulse_end_time - pulse_start_time
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

# Main loop
while True:
    # Read the distance from the sensor
    distance = read_distance()

    # Check if the distance is below the threshold
    if distance < 10: # Change the threshold to the desired value
        # Turn on the buzzer and LED
        GPIO.output(BUZZER_PIN, GPIO.HIGH)
        GPIO.output(LED_PIN, GPIO.HIGH)
    else:
        # Turn off the buzzer and LED
        GPIO.output(BUZZER_PIN, GPIO.LOW)
        GPIO.output(LED_PIN, GPIO.LOW)

    # Wait for a short time before taking the next measurement
    time.sleep(0.1)
