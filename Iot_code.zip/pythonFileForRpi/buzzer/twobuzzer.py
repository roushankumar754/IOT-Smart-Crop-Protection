import RPi.GPIO as GPIO
import time

# Set up GPIO pins for ultrasonic sensors
GPIO.setmode(GPIO.BCM)
GPIO_TRIGGER_1 = 26
GPIO_ECHO_1 = 20
GPIO_TRIGGER_2 = 16
GPIO_ECHO_2 = 19
GPIO.setup(GPIO_TRIGGER_1, GPIO.OUT)
GPIO.setup(GPIO_ECHO_1, GPIO.IN)
GPIO.setup(GPIO_TRIGGER_2, GPIO.OUT)
GPIO.setup(GPIO_ECHO_2, GPIO.IN)

# Set up GPIO pins for buzzers
BUZZER_1_PIN = 21
BUZZER_2_PIN = 13
GPIO.setup(BUZZER_1_PIN, GPIO.OUT)
GPIO.setup(BUZZER_2_PIN, GPIO.OUT)

# Function to measure distance using an ultrasonic sensor
def measure_distance(trigger_pin, echo_pin):
    # Send 10us pulse to trigger pin
    GPIO.output(trigger_pin, True)
    time.sleep(0.00001)
    GPIO.output(trigger_pin, False)

    # Measure pulse duration on echo pin
    pulse_start_time = time.time()
    while GPIO.input(echo_pin) == 0:
        pulse_start_time = time.time()

    pulse_end_time = time.time()
    while GPIO.input(echo_pin) == 1:
        pulse_end_time = time.time()

    pulse_duration = pulse_end_time - pulse_start_time

    # Convert pulse duration to distance in cm
    speed_of_sound = 34300  # cm/s
    distance = pulse_duration * speed_of_sound / 2

    return distance

# Main loop
while True:
    # Measure distances using ultrasonic sensors
    distance_1 = measure_distance(GPIO_TRIGGER_1, GPIO_ECHO_1)
    distance_2 = measure_distance(GPIO_TRIGGER_2, GPIO_ECHO_2)

    # Print distances measured by each sensor
    print("Distance 1: {:.2f} cm".format(distance_1))
    print("Distance 2: {:.2f} cm".format(distance_2))

    # Check if distances are less than a threshold
    distance_threshold = 50  # cm
    if distance_1 < distance_threshold:
        # Trigger buzzer 1
        GPIO.output(BUZZER_1_PIN, True)
    else:
        GPIO.output(BUZZER_1_PIN, False)

    if distance_2 < distance_threshold:
        # Trigger buzzer 2
        GPIO.output(BUZZER_2_PIN, True)
    else:
        GPIO.output(BUZZER_2_PIN, False)

    # Wait for a short time before repeating the loop
    time.sleep(0.1)
