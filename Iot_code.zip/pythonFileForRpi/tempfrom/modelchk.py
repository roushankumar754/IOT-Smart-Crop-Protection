import time
import RPi.GPIO as GPIO
from picamera import PiCamera
import numpy as np
import tensorflow as tf


# set up buzzer GPIO pin
BUZZER_PIN = 3
GPIO.setmode(GPIO.BOARD)
GPIO.setup(BUZZER_PIN, GPIO.OUT)


# initialize camera
camera = PiCamera()
camera.resolution = (224, 224)


# load TensorFlow Lite model
model_path = 'animal_classification_model.tflite'
interpreter = tf.lite.Interpreter(model_path=model_path)
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
interpreter.allocate_tensors()


# classify image
def classify_image(image):
    # pre-process image
    image = np.expand_dims(image, axis=0)
    image = image / 255.0
    image = image.astype('float32')
    
    # set input tensor
    input_tensor = interpreter.tensor(input_details[0]['index'])
    input_tensor()[0, :, :, :] = image
    
    # run model
    interpreter.invoke()
    
    # get output tensor
    output_tensor = interpreter.get_tensor(output_details[0]['index'])
    
    # return class label
    if output_tensor[0][0] > output_tensor[0][1]:
        return 'not_animal'
    else:
        return 'animal'


try:
    while True:
        # capture image
        filename = 'image.jpg'
        camera.capture(filename)

        # load image and classify
        image = tf.keras.preprocessing.image.load_img(filename, target_size=(224, 224))
        image = tf.keras.preprocessing.image.img_to_array(image)
        class_label = classify_image(image)
        
        # produce sound if image contains an animal
        if class_label == 'animal':
            GPIO.output(BUZZER_PIN, True)
            time.sleep(0.5)
            GPIO.output(BUZZER_PIN, False)

except KeyboardInterrupt:
    print("Program stopped by user")
    GPIO.cleanup()
