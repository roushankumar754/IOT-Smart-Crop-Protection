import os
import random
import shutil

# Set the path to your image dataset
dataset_path = "C:/Users/roushan/Desktop/pythonFileForRpi/opencv/animals"

# Set the paths to the output directories for train and validation sets
train_path = "E:/classification/training"
val_path = "E:/classification/validating"

# Set the ratio of the split (e.g., 80% training, 20% validation)
split_ratio = 0.8

# Create the train and validation directories if they don't exist
if not os.path.exists(train_path):
    os.makedirs(train_path)
if not os.path.exists(val_path):
    os.makedirs(val_path)

# Iterate over the "animal" and "notanimal" directories
for label in ["1", "0"]:
    # Set the paths to the label-specific directories in the input and output directories
    src_label_path = os.path.join(dataset_path, label)
    train_label_path = os.path.join(train_path, label)
    val_label_path = os.path.join(val_path, label)
    
    # Create the label-specific directories in the train and validation directories if they don't exist
    if not os.path.exists(train_label_path):
        os.makedirs(train_label_path)
    if not os.path.exists(val_label_path):
        os.makedirs(val_label_path)
    
    # Get the filenames of all images with the current label
    filenames = os.listdir(src_label_path)
    
    # Shuffle the filenames randomly
    random.shuffle(filenames)
    
    # Determine the index to split the filenames based on the split ratio
    split_idx = int(len(filenames) * split_ratio)
    
    # Iterate over the filenames and copy them to either the train or validation directory
    for i, filename in enumerate(filenames):
        src = os.path.join(src_label_path, filename)
        if i < split_idx:
            dst = os.path.join(train_label_path, filename)
        else:
            dst = os.path.join(val_label_path, filename)
        shutil.copy(src, dst)
