import RPi.GPIO as GPIO
import time

led_pin=3
# Set up GPIO pins for LED
GPIO.setmode(GPIO.BOARD)
GPIO.setup(led_pin, GPIO.OUT)

# Set up LM35 temperature sensor
temp_sensor_pin = 2
voltage_reference = 3.3  # voltage reference for analog to digital conversion
sensor_resolution = 1024  # resolution of ADC

def get_temperature():
    # Read the analog voltage from the LM35 sensor
    sensor_value = GPIO.input(temp_sensor_pin)
    # Convert the analog voltage to temperature in Celsius
    voltage = (sensor_value / float(sensor_resolution)) * voltage_reference
    temperature = (voltage - 0.5) * 100
    return temperature

# Loop to continuously check temperature and trigger LED if temperature is too high
while True:
    temperature = get_temperature()
    if temperature > 30:  # Set threshold temperature here
        GPIO.output(led_pin, True)  # Turn on LED
    else:
        GPIO.output(led_pin, False)  # Turn off LED
    time.sleep(1)  # Wait 1 second before checking temperature again
