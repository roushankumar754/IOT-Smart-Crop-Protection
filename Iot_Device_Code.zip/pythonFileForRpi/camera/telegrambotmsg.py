import requests

BOT_TOKEN = '6065099302:AAGvy6HGaiOEv0jKwm6PxOAD6IrVwuwTSGg'
CHAT_ID = '5235622052'

url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto'

# open the image file
with open('corner_2.jpg', 'rb') as f:
    # send a POST request to the Telegram Bot API with the image as multipart/form-data
    response = requests.post(url, data={'chat_id': CHAT_ID}, files={'photo': f})

# check if the request was successful
if response.status_code == 200:
    print('Image sent successfully.')
else:
    print('Error sending image:', response.text)
