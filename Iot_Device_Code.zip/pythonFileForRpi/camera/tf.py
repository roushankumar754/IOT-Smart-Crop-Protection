import RPi.GPIO as GPIO
import time
import cv2
import numpy as np
import tensorflow as tf

# Set up ultrasonic sensor
GPIO.setmode(GPIO.BCM)
TRIG_PIN = 26
ECHO_PIN = 20
GPIO.setup(TRIG_PIN, GPIO.OUT)
GPIO.setup(ECHO_PIN, GPIO.IN)

# Set up camera
cap = cv2.VideoCapture(0)

# Load TensorFlow model
model = tf.keras.models.load_model("animal_detection_model.h5")

# Define labels for classification
labels = ["cat", "dog", "bird", "squirrel", "rabbit", "deer", "fox", "raccoon", "skunk", "moose"]

while True:
    # Get distance from ultrasonic sensor
    GPIO.output(TRIG_PIN, False)
    time.sleep(2)
    GPIO.output(TRIG_PIN, True)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, False)
    while GPIO.input(ECHO_PIN) == 0:
        pulse_start = time.time()
    while GPIO.input(ECHO_PIN) == 1:
        pulse_end = time.time()
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    # Capture image from camera
    ret, frame = cap.read()

    # Resize image to match model input shape
    resized = cv2.resize(frame, (224, 224))

    # Preprocess image for model input
    input_image = np.expand_dims(resized, axis=0)
    input_image = input_image / 255.0

    # Run model inference
    predictions = model.predict(input_image)

    # Get predicted label and confidence score
    max_index = np.argmax(predictions[0])
    label = labels[max_index]
    confidence = predictions[0][max_index]

    # Display output on image
    text = "{}: {:.2f}%".format(label, confidence * 100)
    cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(frame, "Distance: {} cm".format(distance), (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Show the image
    cv2.imshow("Animal Detection", frame)

    # Exit on 'q' keypress
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Clean up resources
GPIO.cleanup()
cap.release()
cv2.destroyAllWindows()
