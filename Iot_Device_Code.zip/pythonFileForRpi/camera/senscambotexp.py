import RPi.GPIO as GPIO
import time
import threading
from picamera import PiCamera
import requests
import Adafruit_DHT

GPIO.setmode(GPIO.BCM)

# initialize ultrasonic sensor GPIO pins
GPIO_TRIGGER = [26, 16, 6, 0]
GPIO_ECHO = [20, 19, 12, 1]

# initialize LED GPIO pins
GPIO_LED = [21, 13, 5, 7]

# Set sensor type : Options are DHT11,DHT22 or AM2302
sensor = Adafruit_DHT.DHT11
# Set GPIO pin number (use BCM GPIO numbering) for humidity
pin = 2

# set up GPIO pins
for i in range(4):
    GPIO.setup(GPIO_TRIGGER[i], GPIO.OUT)
    GPIO.setup(GPIO_ECHO[i], GPIO.IN)
    GPIO.setup(GPIO_LED[i], GPIO.OUT)

# initialize camera
camera = PiCamera()

BOT_TOKEN = '6065099302:AAGvy6HGaiOEv0jKwm6PxOAD6IrVwuwTSGg'
CHAT_ID = '5235622052'
def senseHumidity():
    # Set threshold humidity level
    threshold_humidity = 90
    # Read data from sensor
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

    # Check if reading was successful
    if humidity is not None and temperature is not None:
        print('Temperature={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature, humidity))
        
        # Check if humidity is below threshold
        if humidity < threshold_humidity:
            # Send alert to Telegram bot
            telegram_message = f'Humidity is below threshold: {humidity}% And Temperature={temperature}*C'
            telegram_api_url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage'
            telegram_params = {'chat_id': CHAT_ID, 'text': telegram_message}
            response = requests.post(telegram_api_url, params=telegram_params)
            if response.ok:
                print('Alert sent to Telegram bot')
            else:
                print('Failed to send alert to Telegram bot')
    else:
        print('Failed to get reading from sensor.')
    time.sleep(100)

def measure_distance(trigger_pin, echo_pin):
    # set trigger pin to high for 10us
    GPIO.output(trigger_pin, True)
    time.sleep(0.00001)
    GPIO.output(trigger_pin, False)

    pulse_start = time.time()
    # measure echo pulse duration
    while GPIO.input(echo_pin) == 0:
        pulse_start = time.time()

    while GPIO.input(echo_pin) == 1:
        pulse_end = time.time()

    # calculate distance in cm
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def sendImage(path,corner):
    # open the image file
    with open(path, 'rb') as f:
        # send a POST request to the Telegram Bot API with the image as multipart/form-data
        url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto'
        response = requests.post(url, data={'chat_id': CHAT_ID, 'caption':'object detected at side '+str(corner) }, files={'photo': f})

    # check if the request was successful
    if response.status_code == 200:
        print('Image sent successfully.')
    else:
        print('Error sending image:', response.text)

try:
    while True:
        for i in range(4):
            # measure distance using ultrasonic sensor
            distance = measure_distance(GPIO_TRIGGER[i], GPIO_ECHO[i])
            senseHumidity()
            # check if object is within range
            if distance < 27:
                # turn on LED for corresponding corner
                GPIO.output(GPIO_LED[i], True)
                print(f"Sensor {i+1}:{distance} cm")
                # capture image using camera
                filename = f"corner_{i+1}.jpg"
                camera.capture(filename)
                # send message with image to Telegram
                sendImage(filename,i+1)
                #send_alert_message_with_image(filename)
                print(filename,"sent")
            else:
                # turn off LED for corresponding corner
                GPIO.output(GPIO_LED[i], False)
except KeyboardInterrupt:
    print("Program stopped by user")
    GPIO.cleanup()
