import RPi.GPIO as GPIO
import time

# Set GPIO pin
ledPin = 18

# Set GPIO mode
GPIO.setmode(GPIO.BCM)

# Set GPIO direction
GPIO.setup(ledPin, GPIO.OUT)

# Delay for 5 seconds
time.sleep(5)

# Blink LED
for i in range(5):
    GPIO.output(ledPin, GPIO.HIGH)
    time.sleep(0.5)
    GPIO.output(ledPin, GPIO.LOW)
    time.sleep(0.5)

# Clean up GPIO
GPIO.cleanup()
