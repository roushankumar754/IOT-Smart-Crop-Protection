import RPi.GPIO as GPIO
import time

# Define GPIO pins for ultrasonic sensors and buzzers
trig_pins = [26, 16, 6, 0]
echo_pins = [20, 19, 12, 1]
buzzer_pins = [21, 13, 5, 7]

# Set up GPIO mode and pins
GPIO.setmode(GPIO.BCM)

for i in range(4):
    GPIO.setup(trig_pins[i], GPIO.OUT)
    GPIO.setup(echo_pins[i], GPIO.IN)
    GPIO.setup(buzzer_pins[i], GPIO.OUT)

def measure_distance(trig_pin, echo_pin):
    # Send a 10us pulse to trigger the sensor
    GPIO.output(trig_pin, True)
    time.sleep(0.00001)
    GPIO.output(trig_pin, False)

    # Wait for the echo response
    pulse_start = time.time()
    while GPIO.input(echo_pin) == 0:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(echo_pin) == 1:
        pulse_end = time.time()

    # Calculate distance in centimeters
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)
    return distance

while True:
    for i in range(4):
        distance = measure_distance(trig_pins[i], echo_pins[i])
        #print(f"Sensor {i+1}: {distance} cm")

        if distance < 27:
            GPIO.output(buzzer_pins[i], True)
            print(f"Sensor {i+1}: {distance} cm")
        else:
            GPIO.output(buzzer_pins[i], False)

    time.sleep(0.1)

# Clean up GPIO pins
GPIO.cleanup()
