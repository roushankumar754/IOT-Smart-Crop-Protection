import RPi.GPIO as GPIO
import time
import picamera
import os

# Set up GPIO pins
GPIO.setmode(GPIO.BCM)
TRIG = 23
ECHO = 24
LED = 18
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(LED, GPIO.OUT)

# Set up camera
camera = picamera.PiCamera()
camera.rotation = 180

def capture_image():
    timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"animal_detection_{timestamp}.jpg"
    camera.capture(filename)
    print(f"Image captured: {filename}")

# Main loop
while True:
    # Send ultrasonic pulse
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    # Wait for echo
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()

    # Wait for pulse to end
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    # Calculate distance
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    # Check if animal is within 50cm
    if distance < 50:
        print(f"Animal detected at {distance}cm!")
        # Capture image
        capture_image()
        # Turn on LED
        GPIO.output(LED, True)
        time.sleep(5)  # Wait for 5 seconds
        # Turn off LED
        GPIO.output(LED, False)
