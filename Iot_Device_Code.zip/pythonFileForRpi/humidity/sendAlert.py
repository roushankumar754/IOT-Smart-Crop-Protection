import Adafruit_DHT
import requests

# Set sensor type : Options are DHT11,DHT22 or AM2302
sensor = Adafruit_DHT.DHT11

# Set GPIO pin number (use BCM GPIO numbering)
pin = 2

# Set threshold humidity level
threshold_humidity = 90

# Telegram bot token and chat ID
telegram_bot_token = '6065099302:AAGvy6HGaiOEv0jKwm6PxOAD6IrVwuwTSGg'
telegram_chat_id = '5235622052'

# Read data from sensor
humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

# Check if reading was successful
if humidity is not None and temperature is not None:
    print('Temperature={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature, humidity))
    
    # Check if humidity is below threshold
    if humidity < threshold_humidity:
        # Send alert to Telegram bot
        telegram_message = f'Humidity is below threshold: {humidity}% And Temperature={temperature}*C'
        telegram_api_url = f'https://api.telegram.org/bot{telegram_bot_token}/sendMessage'
        telegram_params = {'chat_id': telegram_chat_id, 'text': telegram_message}
        response = requests.post(telegram_api_url, params=telegram_params)
        if response.ok:
            print('Alert sent to Telegram bot')
        else:
            print('Failed to send alert to Telegram bot')
else:
    print('Failed to get reading from sensor.')
